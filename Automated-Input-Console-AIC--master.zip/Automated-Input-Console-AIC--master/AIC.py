# you must install pywin32 module to use this program
# this program is named - AIC (Automated Input Console)
# it allows you to automatically send input in console program
# you just have to store input data in a file, to press enter key as input
# you must press enter key i.e. change line in the file that contains input
# data, this program may be very helpful to programmer who are testing a
# program which requires several data to input everytime, it can save their time
# it reads input data from file and automatically inputs into program you
# execute using AIC ( Automated Input Console)



import sys
import win32api
import win32com.client
import win32gui
import os
import msvcrt

data=None
name=None
fname=None
while True:
    os.system("cls")
    print '''
    =============================================================
    =            Welcome To Automated Input Console             =
    =                                                           =
    =============================================================
    =                                                           =
    =                                                           =
    =            1.  Load Input Data From File                  =
    =            2.  Enter Program Name                         =
    =            3.  Execute Program in AIC                     =
    =            0.  Exit AIC                                   =
    =                                                           =
    =                                                           =
    =                                                           =
''',
    if fname!=None and len(fname)!=0:
        print "    =                              File Loaded:"+fname[0:17]+" "*(17-len(fname))+"="
    if name!=None and len(name)!=0:
        print "    =                           Program Loaded:"+name[0:17]+" "*(17-len(name))+"="
    print "    ============================================================="
    choice=raw_input("Enter your choice: ")

    if int(choice)==1:
        fname=raw_input("\nEnter file name: ")
        try:
            fin=open(fname,"r")
            data=fin.read()
            fin.close()
        except:
            print "\n\nFailed to open file"
            msvcrt.getch()
            fname=None

    if int(choice)==2:
        name=raw_input("\nEnter program name: ")
        try:
            open(name,"rb").close()
        except:
            print "\n\nFailed to Load Program"
            msvcrt.getch()
            name=None

    if int(choice)==3:
        shell = win32com.client.Dispatch("WScript.Shell")
        shell.Run(name)
        win32api.Sleep(100)
        while(name not in win32gui.GetWindowText (win32gui.GetForegroundWindow())):
            shell.AppActivate(name)
            win32api.Sleep(100)
        for x in data:
            if(x=='+'):
                shell.SendKeys("{+}")
            elif(x=='^'):
                shell.SendKeys("{^}")
            elif(x=='%'):
                shell.SendKeys("{%}")
            elif(x=='~'):
                shell.SendKeys("{~}")
            elif(x!="\n"):
                shell.SendKeys(x)
            else:
                shell.SendKeys("{ENTER}")
            win32api.Sleep(10)

    if int(choice)==0:
        sys.exit(0)
